﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace desafioRosen
{
    class Professor
    {
        public string nome;
        public int matrícula;
        public string email;
    }
    class Curso
    {
        public string nome;
        public string area;
        public int cargaHoraria;
    }
    class Autor
    {
        public string nome;
        public int matrícula;
        public string email;
    }
    class Trabalho
    {
        public string tema;
        public string area;
        public string linkDocumento;
        public string linkGit;
    }
    class Banca
    {
        public string data;
        public int horaInicio;
        public int horaFim;
        public float resultado;
        public string observaçoes;
    }
    class Orientadorindicado
    {
        public int ordemPreferencia;
        public string status;
    }
    class Membroexterno
    {
        public string nome;
        public int telefone;
        public string email;
    }

}
