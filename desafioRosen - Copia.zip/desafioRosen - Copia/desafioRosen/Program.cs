﻿using desafioRosen;
Professor professor = new Professor();
professor.nome = "Kaue";
professor.email = "kauefcpereira@gmail.com";
professor.matrícula = 217936845; 

Curso curso = new Curso();
curso.nome = "sistema de informaçao";
curso.area = "tecnologia";
curso.cargaHoraria = 320;

Autor autor = new Autor();
autor.nome = "João Pedro";
autor.matrícula = 576248345;
autor.email = "joaopedroportugal02@gmail.com";

Trabalho trabalho = new Trabalho();
trabalho.tema = "Avanço da tecnologia";
trabalho.area = "tecnologia";
trabalho.linkDocumento = "www.linkDocumento.com.br";
trabalho.linkGit = "www.linkGit.com.br";

Banca banca = new Banca();
banca.data = "05/01";
banca.horaInicio = 7;
banca.horaFim = 13;
banca.resultado = 8.5f;
banca.observaçoes = "nenhuma";

Orientadorindicado orientadorindicado = new Orientadorindicado();
orientadorindicado.ordemPreferencia = 1;
orientadorindicado.status = "ok";

Membroexterno membroexterno = new Membroexterno();
membroexterno.nome = "Lucas";
membroexterno.telefone = 999223366;
membroexterno.email = "lucasrondelli12@gmail.com";

Console.WriteLine($"Meu nome é {autor.nome} estudo o curso de {curso.nome}");
Console.WriteLine($"O nome do meu professor é {professor.nome} e ele foi indicado para ser meu orientador do trabalho {trabalho.tema}");
Console.WriteLine($"A banca do meu trabalho vai ser no dia {banca.data} de {banca.horaInicio} horas até {banca.horaFim} horas");

